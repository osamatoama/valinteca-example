from src.core import process
from src import api

# Current Codes:
# 52828783
# 50849911
# 98102110
# 85826998
# 53831139
# 81121113
# 11354116
# 11251988
# 12210068
# 10285110


def main():
    # initial data from api
    razer_email = 'osamatoama96@gmail.com'
    razer_password = 'Rc2SaU.vb9jC4Xr'
    active_backup_code = '52828783'

    try:
        result = process(razer_email=razer_email, razer_password=razer_password, initial_backup_code=active_backup_code)
        print(result)
        api.handle_success(success_message=result)
    except Exception as error:
        print(error)
        api.handle_failure(error_message=error)


if __name__=='__main__':
    main()
